'''
6. Write a program to accept an integer and reverse the number. Example: Input: 546, Output
645.
'''

n=int(input("Enter a integer="))
reverse=0

while(n!=0):
    rem=n%10
    n=n//10
    reverse=reverse*10+rem


print("Reversed number=",reverse)
'''
OUTPUT
Enter a integer=123
Reversed number= 321

'''