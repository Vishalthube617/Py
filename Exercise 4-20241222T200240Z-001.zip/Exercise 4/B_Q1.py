''' 1. Write a program to display the first n Fibonacci numbers. (1 1 2 3 5 ……)'''


number=int(input("Enter a number of elements="))
a=0
b=1
print("Fibonacci series:",a,",",b,end=",")
for i in range(2,number):
    c=a+b
    a=b
    b=c
    print(c,",",end="")

'''
OUTPUT
Enter a number of elements=10
Fibonacci series: 0 , 1,1 ,2 ,3 ,5 ,8 ,13 ,21 ,34 ,
'''

