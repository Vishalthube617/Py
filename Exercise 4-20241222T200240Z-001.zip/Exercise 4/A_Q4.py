'''4. Write a program to accept an integer and check if it is prime or not. '''

n=int(input("Enter the number="))

for i in range(2,n+1):
    print(i)
    f=1
    for j in range(2,i):
        if(i%j==0):
            f=0
            break
    if f==1:
            print(i,"is prime")


'''
OUTPUT
Enter the number=10
2
2 is prime
3
3 is prime
4
5
5 is prime
6
7
7 is prime
8
9
10
'''