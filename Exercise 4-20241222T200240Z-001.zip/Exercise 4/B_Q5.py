'''
5. Write a program, which accepts a number n and displays each digit in words. Example: 6702
Output = Six-Seven-Zero-Two. (Hint: Reverse the number and use a switch statement)
'''


num=int(input("Enter a number"))
rem=0
while(num>0):
    rem=rem*10+num%10
    num=num//10
print(rem)
while(rem>0):
    num=rem%10

    if num==1:
        print("one")
    elif num==2:
        print("two")
    elif num==3:
        print("three")
    elif num==4:
        print("four")
    elif num==5:
        print("five")
    elif num==6:
        print("six")
    elif num==7:
        print("seven")
    elif num==8:
        print("eight")
    elif num==9:
        print("nine")
    rem=rem//10

'''
OUTPUT
Enter a number6
6
six
'''