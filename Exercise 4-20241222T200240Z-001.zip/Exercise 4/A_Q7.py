'''7. Write a program to accept a character, an integer n and display the next n characters. '''

char=input("Enter a single character:")
n=int(input("Enter an integer n:"))
start_ascii=ord(char)
print("Next",n , "characters are:")
for i in range(1,n+1):
    next_char=chr(start_ascii+i)
    print(next_char,end=' ')
print()

'''
OUTPUT
Enter a single character:a
Enter an integer n:5
Next 5 characters are:
b c d e f 
'''