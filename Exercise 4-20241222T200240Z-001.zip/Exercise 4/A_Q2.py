'''2. Accept two integers x and y and calculate the sum of all integers between x and y (both
inclusive)'''

x=1
y=0
total_sum=0
while(x>=y):
    print("The second number should be bigger than the first one")
    x=int(input("Enter first number="))
    y = int(input("Enter second number="))
while(x<=y):
    total_sum+=x
    x=x+1
print("Result=",total_sum)

'''
The second number should be bigger than the first one
Enter first number=5
Enter second number=9
REsult= 35

'''