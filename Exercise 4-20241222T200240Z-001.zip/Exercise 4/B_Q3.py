'''
3. Write a program to accept real number x and integer n and calculate the sum of first n terms
of the series 1/x+2/x^2+3/x^3+...

'''

x=int(input("Enter a real number x( x should not be 0): "))
n=int(input("Enter the number of terms n:"))
total_sum=0
for i in range(1,n+1):
    term=i/(x**i)
    total_sum=total_sum+term
print("The sum of the first",n,"terms of the series is:",total_sum)

'''
OUTPUT
Enter a real number x( x should not be 0): 5
Enter the number of terms n:9
The sum of the first 9 terms of the series is: 0.3124986880000001
'''
