''' 5. Write a program to accept an integer and count the number of digits in the number. '''




n=int(input("Enter a number="))
c=0
while(n>0):
    n=n//10
    c=c+1
print("count digit=",c)
'''
OUTPUT:
Enter a number=3452
count digit= 4

'''
