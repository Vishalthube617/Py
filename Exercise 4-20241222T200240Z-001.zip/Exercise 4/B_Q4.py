'''
4. Write a program to accept characters till the user enters EOF and count number of alphabets
and digits entered. Refer to sample program 5 given above.
'''

alpha_count=0
digit_count=0

print("Enter characters ( press Enter on an empty line to end input):")
while True:
    line=input()
    if line=="":
          break
    for char in line:
        char=char.upper()
        if char.isalpha():
               alpha_count=alpha_count+1
        elif char.isdigit():
                digit_count=digit_count+1
print("Number of alphabets entered:",alpha_count)
print("Number of digit entered:",digit_count)
'''
OUTPUT
Enter characters ( press Enter on an empty line to end input):
errtt233

Number of alphabets entered: 5
Number of digit entered: 3
'''
