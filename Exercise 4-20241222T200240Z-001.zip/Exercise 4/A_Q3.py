'''3. Write a program to accept two integers x and n and compute xn'''

x=int(input("Enter a value of x="))
n=int(input("Enter a value of n="))
pow=1
j=1
pow=x
while(n!=j):
    pow=pow*x
    j=j+1
print(x,"to the Power=",n,pow)

'''
OUTPUT
Enter a value of x=4
Enter a value of n=5
4 to the Power= 5 1024

'''