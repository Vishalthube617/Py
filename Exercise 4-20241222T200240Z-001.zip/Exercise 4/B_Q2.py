''' 2. Write a program to accept real number x and integer n and calculate the sum of first n terms
of the series x+ 3x+5x+7x+… '''

x=int(input("Enter value of x="))
n=int(input("Enter limit of n="))
total_sum=0
for i in range(1,n+1):
    term=(2*i-1)*x
    total_sum=total_sum+term
print("The sum of the first",n,"terms of the series is:",total_sum)

'''
OUTPUT
Enter value of x=7
Enter limit of n=5
The sum of the first 5 terms of the series is: 175

'''