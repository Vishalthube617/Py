''' 1. Write a program to accept an integer n and display all even numbers upto n.'''

n=int(input("Enter number:"))
for i in range(1,n):
    if i%2==0:
        print("Even numbers:",i)

'''
OUTPUT
Enter number:100
Even numbers: 2
Even numbers: 4
Even numbers: 6
Even numbers: 8
Even numbers: 10
Even numbers: 12
Even numbers: 14
Even numbers: 16
Even numbers: 18
Even numbers: 20
Even numbers: 22
Even numbers: 24
Even numbers: 26
Even numbers: 28
Even numbers: 30
Even numbers: 32
Even numbers: 34
Even numbers: 36
Even numbers: 38
Even numbers: 40
Even numbers: 42
Even numbers: 44
Even numbers: 46
Even numbers: 48
Even numbers: 50
Even numbers: 52
Even numbers: 54
Even numbers: 56
Even numbers: 58
Even numbers: 60
Even numbers: 62
Even numbers: 64
Even numbers: 66
Even numbers: 68
Even numbers: 70
Even numbers: 72
Even numbers: 74
Even numbers: 76
Even numbers: 78
Even numbers: 80
Even numbers: 82
Even numbers: 84
Even numbers: 86
Even numbers: 88
Even numbers: 90
Even numbers: 92
Even numbers: 94
Even numbers: 96
Even numbers: 98

'''