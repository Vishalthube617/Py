'''
 6. Accept three dimensions length (l), breadth(b) and height(h) of a cuboid and print surface
area and volume (Hint : surface area=2(lb+lh+bh ), volume = lbh )
'''

l=int(input("Enter length="))
b=int(input("Enter breadth="))
h=int(input("Enter volume="))
surface_area=2*(l*b+l*b+b*h)
volume=l*b*h
print("Surface are=",surface_area)
print("volume=",volume)

'''
OUTPUT

Enter length=3
Enter breadth=7
Enter volume=8
Surface are= 196
volume= 168
'''
