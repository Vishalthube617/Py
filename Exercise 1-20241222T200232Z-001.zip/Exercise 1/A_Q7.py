'''
7. Accept a character from the keyboard and display its previous and next character in order.
Ex. If the character entered is ‘d’, display “The previous character is c”, “The next character is e”.
'''

char=input("Enter a character=")
char=ord(char)
p=char-1
n=char+1
#print("you entered=",char)
print("previous character=",chr(p))
print("Next character=",chr(n))
'''
OUTPUT
Enter a character=t
previous character= s
Next character= u

'''