''' 1. Accept the x and y coordinates of two points and compute the distance between the two
points'''
import math
print("Enter the coordinated of A point:")
a=float(input("Enter coordinate x axis="))
b=float(input("Enter coordinate y axis="))
print("Enter the coordinated of B point:")
c=float(input("Enter coordinate x axis="))
d=float(input("Enter coordinate y axis="))

distance=((c-a)*(c-a))+((d-b)*(d-b))
print("Distance between two points=",math.sqrt(distance))

'''
OUTPUT

Enter the coordinated of A point:
Enter coordinate x axis=5
Enter coordinate y axis=2
Enter the coordinated of B point:
Enter coordinate x axis=8
Enter coordinate y axis=4
Distance between two points= 3.605551275463989
'''