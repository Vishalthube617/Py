'''
1. Accept dimensions of a cylinder and print the surface area and volume (Hint: surface area =
2πr(sqr)+ 2πrh, volume = πr(sqr)h)

'''

radius=float(input("Enter the value of radius="))
height=float(input("Enter the value of height="))

surface_area=2*(22/7)*radius*radius+2*(22/7)*radius*height
volume=(22/7)*radius*radius*height

print("surface area of cylinder",surface_area)
print("volume of cylinder",volume)

'''
OUTPUT
Enter the value of radius=4
Enter the value of height=6
surface area of cylinder 251.42857142857144
volume of cylinder 301.7142857142857
'''