'''
 5. Accept two numbers and print arithmetic and harmonic mean of the two numbers (Hint: AM=
(a+b)/2 , HM = ab/(a+b) )
'''

a=int(input("Enter first number="))
b=int(input("Enter second number="))
AM=(a+b)/2
HM=(a*b)/(a+b)
print("Arithmetic Mean=",AM)
print("Harmonic Mean=",HM)

'''
OUTPUT

Enter first number=8
Enter second number=9
Arithmetic Mean= 8.5
Harmonic Mean= 4.235294117647059


'''
