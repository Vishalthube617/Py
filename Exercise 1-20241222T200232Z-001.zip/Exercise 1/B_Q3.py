'''
3. A cashier has currency notes of denomination 1, 5 and 10. Accept the amount to be
withdrawn from the user and print the total number of currency notes of each denomination the
cashier will have to give.
'''

w=int(input("Enter a withdrow amount="))
x=w/10
w=w%10
y=w/5
w=w%5
z=w
print("note of 10=",x)
print("note of 5=",y)
print("note of 1=",z)

'''
OUTPUT
Enter a withdrow amount=678
note of 10= 67.8
note of 5= 1.6
note of 1= 3

'''