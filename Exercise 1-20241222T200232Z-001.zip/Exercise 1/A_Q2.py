'''2. Accept temperatures in Fahrenheit (F) and print it in Celsius(C) and Kelvin (K) (Hint: C=5/9(F32), K = C + 273.15) '''

fahre=float(input("Enter temperature in fahrenheit="))
convert=(fahre-32)*5/9
print("Temperature in celcius:",convert)

'''OUTPUT

Enter temperature in fahrenheit=56
Temperature in celcius: 13.333333333333334
'''