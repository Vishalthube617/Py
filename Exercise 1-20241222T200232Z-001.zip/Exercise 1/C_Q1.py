'''
1. Consider a room having one door and two windows both of the same size. Accept
dimensions of the room, door and window. Print the area to be painted (interior walls) and area to
be whitewashed (roof).
'''



print("Enter Dimensions of room in order:")
lr=float(input("Enter the length="))
wr=float(input("Enter the width="))
hr=float(input("Enter the height="))

print("Enter Dimensions of door in order:")
ld=float(input("Enter the length="))
hd=float(input("Enter the height="))

print("Enter Dimensions of window in order:")
lwin=float(input("Enter the length="))
hwin=float(input("Enter the height="))

paint_area=4*lr*hr-ld*hd-2*lwin*hwin
whitewash_area=lr*wr
print("Area of painted=",paint_area)
print("Area of whitewashed=",whitewash_area)

'''
OUTPUT
Enter Dimensions of room in order:
Enter the length=20
Enter the width=12
Enter the height=10
Enter Dimensions of door in order:
Enter the length=4
Enter the height=6
Enter Dimensions of window in order:
Enter the length=5
Enter the height=5
Area of painted= 726.0
Area of whitewashed= 240.0
'''