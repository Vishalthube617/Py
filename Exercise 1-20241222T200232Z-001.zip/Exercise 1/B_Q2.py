'''
 2. Accept two integers from the user and interchange them. Display the interchanged numbers.
'''

x=int(input("Enter a integer1="))
y=int(input("Enter a integer2="))
print("Before swapping=",x,y)
temp=x
x=y
y=temp
print("After swapping=",x,y)

'''
OUTPUT
Enter a integer1=11
Enter a integer2=13
Before swapping= 11 13
After swapping= 13 11
'''