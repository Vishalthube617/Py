'''
 2. The basic salary of an employee is decided at the time of employment, which may be
different for different employees. Apart from basic, employee gets 10% of basic as house rent,
30% of basic as dearness allowance. A professional tax of 5% of basic is deducted from salary.
Accept the employee id and basic salary for an employee and output the take home salary of the
employee.
'''

emp_id=int(input("Enter employee id="))
basic_salary=float(input("Enter basic salary="))
house_rate=(basic_salary*0.1)
da=(basic_salary*0.3)
tax=(basic_salary*0.05)
m=basic_salary+((house_rate+da)-tax)
print("id=",emp_id,"Salary=",m)

'''
OUTPUT

Enter employee id=564
Enter basic salary=50789
id= 564 Salary= 68565.15
'''