'''4. Accept inner and outer radius of a ring and print the perimeter and area of the ring (Hint:
perimeter = 2 π (a+b) , area = π (a2
-b2
) )'''

in_radius=float(input("Enter inner radius of ring="))
outer_radius=float(input("Enter outer radius of ring="))
perimeter=(2*3.14)*(in_radius+outer_radius)
area=3.14*((in_radius*in_radius)+(outer_radius*outer_radius))
print("perimeter of ring=",perimeter)
print("area of ring=",area)

'''
OUTPUT
Enter inner radius of ring=8
Enter outer radius of ring=9
perimeter of ring= 106.76
area of ring= 455.3

'''
