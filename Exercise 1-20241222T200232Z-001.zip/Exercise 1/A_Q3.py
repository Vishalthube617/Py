'''3. Accept initial velocity (u), acceleration (a) and time (t). Print the final velocity (v) and the
distance (s) travelled. (Hint: v = u + at, s = u + at2
)'''

sec=int(input("Enter the time in second="))
vel=float(input("Enter the initial velocity="))
acc=float(input("Enter the acceleration="))
velocity=(vel+(acc*sec))
distance=(vel+(acc*(sec*sec)))
print("final velocity=",velocity)
print("distance travelled=",distance)

'''
OUTPUT
Enter the time in second=60
Enter the initial velocity=5
Enter the acceleration=7
final velocity= 425.0
distance travelled= 25205.0
'''