'''
8. Accept a character from the user and display its ASCII value.
'''

char=input("Enter the character=")
print("ASCII valuee of=",ord(char))

'''
OUTPUT
Enter the character=u
ASCII valuee of= 117
'''