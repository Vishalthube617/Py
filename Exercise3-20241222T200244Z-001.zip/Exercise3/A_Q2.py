''' 2. Write a program, which accepts two integers and an operator as a character (+ - * /),
performs the corresponding operation and displays the result. '''



choice=input("Enter choice(1,2,3,4):")
num1=float(input("Enter first number="))
num2=float(input("Enter second number="))

if choice=='1':
    result=num1+num2
    print("Addition=",result)
elif choice=='2':
    result=num1-num2
    print("Subtraction=", result)
elif choice=='3':
    result=num1*num2
    print("Multiplication=", result)
elif choice=='4':
    result=num1/num2
    print("Division=", result)
else:
    print("Invalid input")


'''
Enter choice(1,2,3,4):1
Enter first number=56
Enter second number=67
Addition= 123.0

Enter choice(1,2,3,4):2
Enter first number=10
Enter second number=9
Subtraction= 1.0

Enter choice(1,2,3,4):3
Enter first number=2
Enter second number=3
Multiplication= 6.0

Enter choice(1,2,3,4):4
Enter first number=10
Enter second number=2
Division= 5.0
'''