'''2. Write a program having menu that has three options - add, subtract or multiply two fractions.
The two fractions and the options are taken as input and the result is displayed as output. Each
fraction is read as two integers, numerator and denominator'''

a=int(input("Enter value of a="))
b=int(input("Enter value of b="))
c=int(input("Enter value of c="))
d=int(input("Enter value of d="))

ch=input("Enter your ch(1,2,3):")

if ch=='1':
    nu=(a*d)+(c*b)
    de=(b*d)
    print("Add is",nu,de)
elif ch=='2':
    nu = (a * d) - (c * b)
    de = (b * d)
    print("Sub is", nu, de)
elif ch=='3':
    nu=(a*c)
    de=(b*d)
    print("Mul is",nu,de)
else:
    print("Invalid choice")

'''
OUTPUT
Enter value of a=4
Enter value of b=5
Enter value of c=5
Enter value of d=6
Enter your ch(1,2,3):1
Add is 49 30

Enter value of a=4
Enter value of b=5
Enter value of c=5
Enter value of d=6
Enter your ch(1,2,3):2
Sub is -1 30

Enter value of a=4
Enter value of b=5
Enter value of c=5
Enter value of d=6
Enter your ch(1,2,3):3
Mul is 20 30

'''