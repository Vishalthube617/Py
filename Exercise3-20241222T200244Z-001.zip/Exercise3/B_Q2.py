'''2. Write a program having a menu with the following options and corresponding actions
Options Actions
1. Area of square Accept length ,Compute area of square and print
2. Area of Rectangle Accept length and breadth, Compute area of rectangle
and print
3. Area of triangle Accept base and height , Compute area of triangle and
print'''



ch=input("Enter your ch(1,2,3):")

if ch=='1':
    radius = int(input("Enter a radius="))
    AreaofSquare=radius*radius
    print("Area of square=", AreaofSquare)
elif ch=='2':
    length = int(input("Enter a length="))
    width = int(input("Enter a width="))
    AreaofRectangle=length*width
    print("Area of Rectangle=", AreaofRectangle)
elif ch=='3':
    base = int(input("Enter a base="))
    height = int(input("Enter a height="))
    AreaofTriangle=0.5*base*height
    print("Area of Triangle=", AreaofTriangle)
else:
    print("Invalid choice")



'''
OUTPUT

Enter your ch(1,2,3):1
Enter a radius=4
Area of square= 16

Enter your ch(1,2,3):2
Enter a length=7
Enter a width=6
Area of Rectangle= 42

Enter your ch(1,2,3):3
Enter a base=4
Enter a height=5
Area of Triangle= 10.0
'''