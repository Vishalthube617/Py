'''1. Accept the three positive integers for date from the user (day, month and year) and check
whether the date is valid or invalid. Run your program for the following dates and fill the table.
(Hint: For valid date 1<=month<=12,1<= day <=no-of-days where no-of-days is 30 in case of
months 4, 6,9 and 11. 31 in case of months 1,3,5,7,8,10 and 12. In case of month 2 no-of-days is
28 or 29 depending on year is leap or not)
Date Output
12-10-1984
32-10-1920
10-13-1984
29-2-1984
29-2-2003
29-2-1900
__________
'''

yy=int(input("Enter a year:"))
mm=int(input("Enter a month:"))
dd=int(input("Enter a day:"))

if(yy>=1900 and yy<=2020):
      if(mm>=1 and mm<=12):
            if((dd>=1 and dd<=31) and (mm==1  or mm==3  or mm==5   or mm==7 or mm==8  or  mm==10  or mm==12 ) ):
                  print("Date is valid")
            elif((dd>=1 and dd<=30) and (mm==4 or mm==6 or mm==9 or mm==11)):
                  print("date is valid")
            elif ((dd >= 1 and dd <= 28) and (mm == 2)):
                  print("date is valid")
            elif(dd==29 and mm==2 and (yy%400==0 or (yy%4==0 and yy%100!=0))):
                  print("date is valid")
            else:
                  print("day is invalid")
      else:
            print("month is invalid")
else:
      print("year is invalid")


'''
OUTPUT

Enter a year:1984
Enter a month:10
Enter a day:12
Date is valid

Enter a year:1920
Enter a month:10
Enter a day:30
Date is valid

Enter a year:1984
Enter a month:13
Enter a day:10
month is invalid

Enter a year:2003
Enter a month:2
Enter a day:29
day is invalid

Enter a year:1900
Enter a month:2
Enter a day:29
day is invalid


'''






