'''1. Accept radius from the user and write a program having menu with the following options and
corresponding actions
Options Actions
1. Area of Circle Compute area of circle and print
2. Circumference of Circle Compute Circumference of circle and print
3. Volume of Sphere Compute Volume of Sphere and print'''

radius=int(input("Enter a radius="))

ch=input("Enter your ch(1,2,3):")

if ch=='1':
    area=3.14*radius*radius
    print("Area of Circle=", area)
elif ch=='2':
    CI=2*3.14*radius
    print("Circumference of circle=", CI)
elif ch=='3':
    Volume=(4/3)*(3.14)*radius*radius*radius
    print("Volume of Sphere=", Volume)


'''
OUTPUT:
Enter a radius=2
Enter your ch(1,2,3):1
Area of Circle= 12.56

Enter a radius=2
Enter your ch(1,2,3):2
Circumference of circle= 12.56

Enter a radius=4
Enter your ch(1,2,3):3
Volume of Sphere= 267.94666666666666
'''