'''3. Accept two numbers in variables x and y from the user and perform the following operations
Options Actions
1. Equality Check if x is equal to y
2. Less Than Check if x is less than y
3. Quotient and Remainder Divide x by y and display the quotient and remainder
4. Range Accept a number and check if it lies between x and y
(both inclusive)
5. Swap Interchange x and y
'''

x=float(input("Enter the value of x="))
y=float(input("Enter the value of y="))

print("1.Equality check:",
      "2.Less than check:",
      "3.Quotient and Remainder:",
      "4.Range Accept:",
       "5.Swap Values:")

ch=input("Enter your ch(1,2,3,4,5,6):")
if ch=='1':
        if x==y:
              print("x is equal to y")
        else:
            print("x is not equal to y")
elif ch=='2':
         if x<y:
            print("x is less than y")
         else:
             print("x is not less than y")
elif ch=='3':
         if y!=0:
           q=x/y
           print("Quotient=",q)
           r=x%y
           print("remainder=",r)
         else:
             print("cannot divided by zero")
elif ch=='4':
            num=float(input("Enter a number="))
            if x<=num<=y or y<=num<=x:
                  print("number lies between x and y")
            else:
                print("number is not lies between x and y")
elif ch=='5':
         swap = x
         x = y
         y = swap
         print("The value of x after swapping=",x)
         print("The value of y after swapping=", y)
elif ch=='6':
        print("invalid")

'''
OUTPUT
Enter the value of x=3
Enter the value of y=3
1.Equality check: 2.Less than check: 3.Quotient and Remainder: 4.Range Accept: 5.Swap Values:
Enter your ch(1,2,3,4,5,6):1
x is equal to y

Enter the value of x=2
Enter the value of y=4
1.Equality check: 2.Less than check: 3.Quotient and Remainder: 4.Range Accept: 5.Swap Values:
Enter your ch(1,2,3,4,5,6):2
x is less than y

Enter the value of x=4
Enter the value of y=2
1.Equality check: 2.Less than check: 3.Quotient and Remainder: 4.Range Accept: 5.Swap Values:
Enter your ch(1,2,3,4,5,6):3
Quotient= 2.0
remainder= 0.0

Enter the value of x=3
Enter the value of y=8
1.Equality check: 2.Less than check: 3.Quotient and Remainder: 4.Range Accept: 5.Swap Values:
Enter your ch(1,2,3,4,5,6):4
Enter a number=5
number lies between x and y

Enter the value of x=5
Enter the value of y=6
1.Equality check: 2.Less than check: 3.Quotient and Remainder: 4.Range Accept: 5.Swap Values:
Enter your ch(1,2,3,4,5,6):5
The value of x after swapping= 6.0
The value of y after swapping= 5.0

'''

