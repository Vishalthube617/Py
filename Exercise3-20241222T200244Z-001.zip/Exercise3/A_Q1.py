'''1. Accept a single digit from the user and display it in words. For example, if digit entered is 9,
display Nine.'''

digit_to_word={
    '0':'Zero',
    '1':'One',
    '2':'Two',
    '3':'Three',
    '4':'Four',
    '5':'Five',
    '6':'Six',
    '7':'Seven',
    '8':'Eight',
    '9':'Nine'
}
digit=input("Enter a single digit:")
if digit in digit_to_word:
    print(digit_to_word[digit])
else:
    print("Invalid input.Please enter a single digit between 0 and 9")

'''
OUTPUT:
Enter a single digit:6
Six

'''

