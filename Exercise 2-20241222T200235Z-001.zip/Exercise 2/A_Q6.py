'''6. Accept a lowercase character from the user and check whether the character is a vowel or
consonant. (Hint: a,e,i,o,u are vowels)'''

ch=input("Enter the character:")
if(ch=='a' or ch=='e'or ch=='i' or ch=='o' or  ch=='u' or ch=='A' or ch=='E'or ch=='I' or ch=='O' or  ch=='U'):
     print("character is vowel")
else:
    print("charcter is consonant")

'''
OUTPUT
Enter the character: i
character is vowel

Enter the character:k
charcter is consonant

'''