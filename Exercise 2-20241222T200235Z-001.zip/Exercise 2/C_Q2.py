'''2. Write a program to accept quantity and rate for three items, compute the total sales amount,
Also compute and print the discount as follows: (amount > ____– 20% discount, amount between
___ to _____ -- 15% discount, amount between – ____ to ____ -- 8 % discount)'''

kq=int(input("Enter the quantity of keyboard="))
kr=int(input("Enter the rate of keyboard="))
mq=int(input("Enter the quantity of mouse="))
mr=int(input("Enter the rate of mouse="))
moq=int(input("Enter the quantity of monitor="))
mor=int(input("Enter the rate of monitor="))

TA=kq*kr+mq*mr+moq*mor
if(TA>=20000):
    dis=TA*0.2
    NA=TA-dis
    print(TA,NA,dis)
elif(TA<20000 and TA>15000):
    dis = TA * 0.15
    NA = TA - dis
    print(TA, NA, dis)
elif (TA < 15000 and TA > 10000):
    dis = TA * 0.8
    NA = TA - dis
    print(TA, NA, dis)
else:
    print("Invalid")

'''
OUTPUT
Enter the quantity of keyboard=5
Enter the rate of keyboard=300
Enter the quantity of mouse=3
Enter the rate of mouse=200
Enter the quantity of monitor=6
Enter the rate of monitor=16000
98100 78480.0 19620.0
'''
