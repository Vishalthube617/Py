
'''3. Accept any year as input through the keyboard. Write a program to check whether the year is
a leap year or not. (Hint leap year is divisible by 4 and not by 100 or divisible by 400) '''

year=int(input("enter a year"))
if((year%4==0) and (year%100!=0) or (year%400==0)):
    print("year is leap ")
else:
    print("year is not leap")

'''
OUTPUT
enter a year2016
year is leap 

enter a year2019
year is not leap
'''