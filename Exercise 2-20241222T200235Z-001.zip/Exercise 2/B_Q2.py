'''
2. Accept the time as hour, minute and seconds and check whether the time is valid. (Hint:
0<=hour<24, 0<=minute <60, 0<=second <60)
'''
h=int(input("Enter the hour:"))
m=int(input("Enter the minute:"))
s=int(input("Enter the second:"))

if((h>=0 and h<24) and (m>=0 and m<60) and (s>=0 and s<60)):
    print("valid")
else:
    print("invalid")

'''
OUTPUT

Enter the hour:12
Enter the minute:45
Enter the second:56
valid

Enter the hour:90
Enter the minute:87
Enter the second:76
invalid

'''