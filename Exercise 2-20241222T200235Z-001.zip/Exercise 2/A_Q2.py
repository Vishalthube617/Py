
'''2. Write a program to accept three numbers and check whether the first is between the other
two numbers. Ex: Input 20 10 30. Output: 20 is between 10 and 30 '''

x=int(input("Enter a number x:"))
y=int(input("Enter a number y:"))
z=int(input("Enter a number z:"))

if(x>=y and x<=z):
    print("first number between other two number")
else:
    print("first number is not  between other two number")

    '''
    output
    Enter a number x:20
Enter a number y:10
Enter a number z:30
first number between other two number

Enter a number x:75
Enter a number y:10
Enter a number z:65
first number is not  between other two number

    '''