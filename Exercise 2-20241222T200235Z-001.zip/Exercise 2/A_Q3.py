'''3. Accept a character as input and check whether the character is a digit. (Check if it is in the
range ‘0’ to ‘9’ both inclusive) '''

c=(input("Enter a character:"))
if(c>='0'and c<='9'):
    print("charcter is digit")
else:
    print("character is not digit")

'''
OUTPUT
Enter a character:6
charcter is digit

Enter a character:h
character is not digit


'''


