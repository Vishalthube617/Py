
''' 4. Write a program to accept a number and check if it is divisible by 5 and 7.'''
n=int(input("Enter a number:"))
if n%5==0 and n%7==0:
    print("number is divisible 5 and 7")
elif n%5==0:
    print("number is divisible by 5 ")
elif n%7==0:
    print("number is divisible by 7 ")
else:
    print("number is not divisible by 5 and 7")

'''
OUTPUT
Enter a number:35
number is divisible 5 and 7

Enter a number:50
number is divisible by 5 

Enter a number:49
number is divisible by 7 

Enter a number:89
number is not divisible by 5 and 7

'''