''' 4. Accept three sides of triangle as input, and print whether the triangle is valid or not. (Hint:
The triangle is valid if the sum of each of the two sides is greater than the third side). '''

s1=int(input("Enter a side1"))
s2=int(input("Enter a side2"))
s3=int(input("Enter a side3"))
if((s1+s2)>s3):
    if((s2+s3)>s1):
        if((s1+s3)>s2):
            print("traingle is valid")
        else:
            print("triangle is not valid")
    else:
        print("triangle is not valid")
else:
    print("triangle is not valid")

'''
OUTPUT

Enter a side14
Enter a side26
Enter a side37
traingle is valid

Enter a side167
Enter a side212
Enter a side39
triangle is not valid

'''