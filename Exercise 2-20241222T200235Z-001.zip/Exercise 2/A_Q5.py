''' 5. Write a program, which accepts annual basic salary of an employee and calculates and
displays the Income tax as per the following rules.
Basic: < 1,50,000 Tax = 0
 1,50,000 to 3,00,000 Tax = 20%
 > 3,00,000 Tax = 30%'''

a=int(input("Enter the salary:"))
if a<150000:
    print("Tax=0")
elif a>150000  and a<300000:
    print("Tax=20%")
elif a>300000:
    print("Tax=30%")

'''
OUTPUT
Enter the salary:80000
Tax=0

Enter the salary: 180000
Tax=20%

Enter the salary:400000
Tax=30%
'''