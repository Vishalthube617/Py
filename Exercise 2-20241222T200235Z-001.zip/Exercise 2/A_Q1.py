''' 1. Write a program to accept an integer and check if it is even or odd.'''


n=int(input("Enter a number:"))
if n%2==0:
    print("number is even")
else:
    print("number is odd")

'''
OUTPUT

Enter a number:34
number is even

Enter a number:-34
number is odd
 
'''