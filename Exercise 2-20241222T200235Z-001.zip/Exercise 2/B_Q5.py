''' 5. Accept the x and y coordinate of a point and find the quadrant in which the point lies. '''

x=int(input("Enter the value of x:"))
y=int(input("Enter the value of y:"))
if(x>0 and y>0):
    print("lies in the first quadrant")
elif(x<0 and y>0):
    print("lies in the second quadrant")
elif(x<0 and y<0):
    print("lies in the third quadrant")
elif(x>0 and y<0):
    print("lies in the fourth quadrant")
elif(x==0 and y==0):
    print("lies at the origin")
else:
    print('value invalid')

'''
OUTPUT

Enter the value of x:3
Enter the value of y:8
lies in the first quadrant

Enter the value of x:-9
Enter the value of y:7
lies in the second quadrant

Enter the value of x:-5
Enter the value of y:-4
lies in the third quadrant

Enter the value of x:4
Enter the value of y:-7
lies in the fourth quadrant

'''