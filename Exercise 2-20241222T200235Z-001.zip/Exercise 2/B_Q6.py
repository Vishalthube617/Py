'''6. Write a program to calculate the roots of a quadratic equation. Consider all possible cases'''

import cmath
a=int(input("Enter a:"))
b=int(input("Enter b:"))
c=int(input("Enter c:"))
d=b*b-4*a*c

if d>0:
    root1=(-b-cmath.sqrt(d))/(2*a)
    root2 = (-b + cmath.sqrt(d)) / (2 * a)
    print("2 roots")

elif d<0:
    root1 = (-b - cmath.sqrt(d)) / (2 * a)
    root2 = (-b + cmath.sqrt(d)) / (2 * a)
    print("no roots")
else:
    print("same roots")

'''
OUTPUT
Enter a:-9
Enter b:5
Enter c:9
2 roots

Enter a:6
Enter b:3
Enter c:8
no roots

'''

