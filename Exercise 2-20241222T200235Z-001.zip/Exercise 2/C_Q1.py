'''1. Write a program to accept marks for three subjects and find the total marks secured ,
average and also display the class obtained. (Class I – above __%, class II – ___% to ___%,
pass class – ___% to ___% and fail otherwise)'''

m1=int(input("Enter marks of subject1="))
m2=int(input("Enter marks of subject2="))
m3=int(input("Enter marks of subject3="))
percentage=m1+m2+m3*100/90
print("percentage", percentage)
average=m1+m2+m3/3
print("Average",average)
if percentage>90:
    print("class I")
elif percentage>80 and percentage<90:
    print("class II")
elif percentage>35 and percentage<100:
    print("pass")
else:
    print("fail")

'''
OUTPUT

Enter marks of subject1=30
Enter marks of subject2=40
Enter marks of subject3=50
percentage 125.55555555555556
Average 86.66666666666667
class I

Enter marks of subject1=30
Enter marks of subject2=25
Enter marks of subject3=29
percentage 87.22222222222223
Average 64.66666666666667
class II

Enter marks of subject1=20
Enter marks of subject2=30
Enter marks of subject3=12
percentage 63.333333333333336
Average 54.0
pass
'''

