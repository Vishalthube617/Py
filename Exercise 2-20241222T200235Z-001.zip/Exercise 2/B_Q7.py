
'''7. Accept the cost price and selling price from the keyboard. Find out if the seller has made a
profit or loss and display how much profit or loss has been made.'''

c=float(input("Enter cost of keyboard"))
s=float(input("Enter selling price of keyboard"))
m=c-s
if(m>0):
    print("profit")
elif m<0:
    m=(-1)*m
    print("loss")
else:
    print("no profit no loss")

'''
OUTPUT
Enter cost of keyboard70
Enter selling price of keyboard100
loss

Enter cost of keyboard60
Enter selling price of keyboard30
profit
'''