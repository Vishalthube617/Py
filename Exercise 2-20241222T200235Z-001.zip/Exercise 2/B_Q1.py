'''1. Write a program to check whether given character is a digit or a character in lowercase or
uppercase alphabet. (Hint ASCII value of digit is between 48 to 58 and Lowercase characters
have ASCII values in the range of 97 to122, uppercase is between 65 and 90)'''

ch=input("Enter the character:")
if(ch>='A' and ch<='Z'):
    print("charcter is Uppercase")
elif(ch>='a' and ch<='z'):
    print("charcter is lowercase")
elif(ch>='0' and ch<='9'):
    print("charcter is digit")
else:
    print("charcter not valid")

'''
OUTPUT
Enter the character:A
charcter is Uppercase

Enter the character:a
charcter is lowercase

Enter the character:9
charcter is digit

Enter the character:@
charcter not valid


'''