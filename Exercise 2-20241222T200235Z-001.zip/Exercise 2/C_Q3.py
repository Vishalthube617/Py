'''3. A library charges a fine for every book returned late. Accept the number of days the member 
is late, compute and print the fine as follows:(less than five days Rs ___ fine, for 6 to 10 days Rs. 
____ fine and above 10 days Rs. ___ fine ) '''

d=int(input("Enter the days="))
if d<5:
    print("less than 5 days=Rs 10 fine")
elif d<10 and d>5:
    print("more than 5 days=Rs 20 fine")
elif d>10:
    print("more than 10 days=Rs 30 fine")
'''
Enter the days=3
less than 5 days=Rs 10 fine

Enter the days=7
more than 5 days=Rs 20 fine

Enter the days=12
more than 10 days=Rs 30 fine
'''