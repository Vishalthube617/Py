'''a=int(input("Enter a number:"))
if a%7==0:
    print("number is divisible by7")
else:
    print("number is not divisible by7")
    '''

'''a=int(input("Enter a number:"))
if a%7==0 and a%5==0:
    print("number is divisible by 7 and 5")
else:
    print("number is not divisible by 7 and 5")
    '''




