a=int(input("Enter a number:"))
if a%2==0:
    print("number is positive")
else:
    print("number is negative")